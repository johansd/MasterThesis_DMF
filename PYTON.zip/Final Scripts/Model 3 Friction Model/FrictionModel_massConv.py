from FrictionModel_massConv_lib import *
import numpy as np
import matplotlib.pyplot as plt
import time
import csv

# This script was used to study the convergence of the number of arc-spring masses for the RMS value of the frictional torques. The simulation time
# for different number of arc-spring masses were also studied.

# INPUT #------------------
plot_conv = True    # plot (true) or simulate and save data (false)
# these operators states the which data that should be plotted or be saved
conv_data = False
disp_data = False
simtime_mass = True
plot_time = 0.99
#-------------------------

speed = np.array([800, 1400, 2000])
#numberofmasses = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 25, 30, 35, 40, 50, 60, 70, 80, 90, 100])
numberofmasses = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 25, 30])
#numberofmasses = np.array([1, 2])

torq = np.array([3000, 2000])     # [3000, 2000], [300, 500]

# these structural parameters are not used, the one used are readed from a CSV file
j = np.array([1.8, 0.6])
k = np.array([20000, 11000])
c = np.array([300, 10])

def get_num(x):
    return int(''.join(ele for ele in x if ele.isdigit()))

tstart = 0
tend = 10
taccur = 10
ntstep = 50000
t = np.linspace(tstart, tend, ntstep)

# Newmark-beta parameters
beta = 1/4
gamma = 1/2


speed_legend = []
mass_legend = []
mass_legend2 = []
rms_python = np.zeros(len(speed))


linetype = ['b', 'g--', 'r:']
if plot_conv is False:
    # the simulations for mass convergence(RMS value of the frictional torque), simulation time, angular displacement range for the different number of arc-spring masses
    # are saved to a CSV file using this code
    for rpm in speed:
        i = 0
        print('rpm:')
        print(rpm, '\n')

        for nmasses in numberofmasses:
            start = time.time()
            i += 1

            omega = 2*np.pi*rpm/60

            NBhandle = NewmarkBeta(j, c, k, rpm, [tstart, tend], ntstep, torq, taccur, beta, gamma, nmasses)

            ndof = int(NBhandle.ndof)
            idisp = np.array([0]*ndof)
            ivel = np.array([omega]*ndof)

            u, du, ddu, error, fric_torque, fric_torque_all, fric_force, fric_bearing, fric_force_comp, fric_force_cent = NBhandle.solve_nl(idisp, ivel)

            end = time.time()
            simtime = end-start

            print('Simulation of Mass '+str(i)+' time:')
            print(str(simtime)+' s', '\n')

            if conv_data is True:
                with open('MassConv/FricMod_'+str(rpm)+'_Masses_'+str(nmasses)+'.csv', 'w') as csv_file:
                    writer = csv.writer(csv_file, delimiter=';', lineterminator='\n')
                    for ii in range(int(plot_time*ntstep), ntstep):
                        writer.writerow(fric_torque_all[:, ii])
            elif disp_data is True:
                with open('MassConv/DispTime_'+str(rpm)+'_Masses_'+str(nmasses)+'.csv', 'w') as csv_file:
                    writer = csv.writer(csv_file, delimiter=';', lineterminator='\n')
                    for ii in range(int(plot_time*ntstep), ntstep):
                        writer.writerow([u[:, ii], simtime])

elif plot_conv is True:
    # plots the result for the chosen simulations stored (this is chosen in the beginning under INPUT)

    #rpm = 2000
    #numberofmasses = np.array([5])
    #numberofmasses = np.array([1, 2, 3, 4, 5])
    ntstep_conv = len(range(int(plot_time * ntstep), ntstep))

    if conv_data is True:
        ii = 0
        torqueRmsVal = np.zeros(len(speed))
        torque_compens = np.zeros(len(speed))
        for rpm in speed:
            speed_legend.append(str(rpm) + ' rpm')
            k = 0
            torqueRmsConv = np.zeros(len(numberofmasses))
            for nmasses in numberofmasses:
                frictorque_conv = np.zeros((ntstep_conv, nmasses))
                #print(np.shape(frictorque_conv))
                with open('MassConv/FricMod_' + str(rpm) + '_Masses_' + str(nmasses) + '.csv', 'r') as csv_file:
                    reader = csv.reader(csv_file, delimiter=';')
                    i = 0
                    for row in reader:
                        j = 0
                        for value in row:
                            #print(value)
                            frictorque_conv[i, j] = value
                            #print(frictorque_conv)
                            j += 1
                        i += 1

                #print(len(np.sum(frictorque_conv, axis=1)))
                #print(len(t[plot_time*ntstep:]))
                torqueRmsConv[k] = np.sqrt(1/(0.1)*np.trapz(np.square(np.sum(frictorque_conv, axis=1)), t[plot_time*ntstep:]))
                #print('RMS-Value')
                #print(rms_python)
                k += 1

            torqueRmsVal[ii] = torqueRmsConv[4]
            torque_compens[ii] = 1+(torqueRmsConv[-1]-torqueRmsConv[4])/(torqueRmsConv[-1])

            plt.figure(1)
            # plt.figure(7)
            # plt.title('Friction force')
            plt.plot(numberofmasses, torqueRmsConv, linetype[ii], linewidth=1.5)
            #plt.plot(5, torqueRmsConv[4], 'ro', ms=5)
            plt.xlabel('Number of arc-spring masses')
            plt.ylabel('RMS-value (Angular momentum) [Nm s]')
            plt.grid()
            plt.legend(speed_legend)
            #plt.plot(5, torqueRmsConv[4], 'ro', ms=5)


            ii += 1

        plt.figure(1)
        plt.plot([5, 5, 5], torqueRmsVal, 'ro', ms=5)
        plt.savefig('figures/MassConv.png', dpi=300)

        print(torque_compens)

    elif disp_data is True:
        for rpm in speed:
            print('rpm:')
            print(rpm, '\n')
            speed_legend.append(str(rpm) + ' rpm')
            k = 0
            dispRange_masses = np.zeros(len(numberofmasses))
            times = np.zeros(len(numberofmasses))
            for nmasses in numberofmasses:
                print('Mass: ' +str(nmasses), '\n')
                u = np.zeros((nmasses+2, ntstep_conv))
                # print(np.shape(frictorque_conv))
                with open('MassConv/DispTime_' + str(rpm) + '_Masses_' + str(nmasses) + '.csv', 'r') as csv_file:
                    reader = csv.reader(csv_file, delimiter=';')
                    i = 0
                    for row in reader:
                        time_mass = float(row[1])

                        row2 = row[0]
                        row2 = row2.strip("[] ")
                        #print([row2])
                        row2 = row2.split('  ')
                        while row2.count('') > 0:
                            row2.remove('')
                        #if '' in row2:
                        #    count = 0
                        #    for val in row2:
                        #        if val is '':
                        #            del row2[count]
                        #        count += 1

                        ii = 0
                        u_disp = np.zeros(len(row2))
                        for value in row2:
                            #print(value)
                            current_value = value.strip(' ')

                            current_value = current_value.strip('\n')
                            #print(current_value)
                            #print(row2)
                            #print(get_num(value))

                            u_disp[ii] = float(current_value)
                            #print(u_disp)
                            ii += 1

                        j = 0
                        #print(u_disp)
                        for values in u_disp:
                            #print(values)
                            u[j, i] = values
                            #print(u)
                            j += 1

                        i += 1

                dispRange_masses[k] = max(u[0, :]-u[-2, :])-min(u[0, :] - u[-2, :])
                times[k] = time_mass
                k += 1
                #print('hhh')

            plt.figure(1)
            # plt.figure(7)
            # plt.title('Friction force')
            plt.plot(numberofmasses, dispRange_masses)
            # plt.plot(5, torqueRmsConv[4], 'ro', ms=5)
            plt.xlabel('Number of arc-spring masses')
            plt.ylabel('Relative angular displacement, (Range) [rad]')
            plt.grid()
            plt.legend(speed_legend)
            plt.savefig('figures/MassConv.png', dpi=300)

    elif simtime_mass is True:
        for rpm in speed:
            print('rpm:')
            print(rpm, '\n')

            speed_legend.append(str(rpm) + ' rpm')
            k = 0
            times = np.zeros(len(numberofmasses))
            for nmasses in numberofmasses:
                #print('Mass: ' +str(nmasses), '\n')
                with open('MassConv/DispTime_' + str(rpm) + '_Masses_' + str(nmasses) + '.csv', 'r') as csv_file:
                    reader = csv.reader(csv_file, delimiter=';')

                    for row in reader:
                        times[k] = float(row[1])
                        #print(times[k])
                        break
                k += 1

            plt.figure(1)
            # plt.figure(7)
            # plt.title('Friction force')
            plt.plot(numberofmasses, times)
            # plt.plot(5, torqueRmsConv[4], 'ro', ms=5)
            plt.xlabel('Number of arc-spring masses')
            plt.ylabel('Simulation time [s]')
            plt.grid()
            plt.legend(speed_legend, loc=9)
            plt.savefig('figures/Simtime.png', dpi=300)


    plt.show()

