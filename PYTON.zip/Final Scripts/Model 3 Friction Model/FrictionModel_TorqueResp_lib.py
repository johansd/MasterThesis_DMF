import numpy as np
from scipy.linalg import *
from scipy.optimize import fsolve
from scipy import sparse
import math
import time

class NewmarkBeta:
    def __init__(self, j, c, k, eng_freq, omegaload, ampload, meanload, ti, ntstep, torq, accuracy, beta, gamma, torsionCase, bc):
        self.beta = beta
        self.gamma = gamma
        self.acc = accuracy
        self.tstart = ti[0]
        self.tend = ti[1]
        self.inert = j
        self.damp = c
        self.stiff = k
        self.omega = eng_freq
        #self.ntstep = int(math.ceil((self.tend - self.tstart)*self.get_number_timesteps()*self.acc/100)*100)
        self.ntstep = ntstep
        self.torq_mean = torq[0]
        self.torq_amp = torq[1]
        self.torsionCase = torsionCase

        self.bc = bc
        self.gp, self.struct_param = DMFModel(1, self.bc, self.torsionCase).dmf_param(1)
        self.J, self.C, self.K = DMFModel(1, self.bc, self.torsionCase).model_assem(1, 1)
        self.ndof = self.J.shape[0]
        self.ndof_full = self.J.shape[0] + len(self.bc)

        self.meanload = meanload
        self.ampload = ampload
        self.omegaload = omegaload

        self.tincr = 1

    def initialize_newmark(self):
        J, C, K = DMFModel(1).model_assem(1, 1)
        return J, C, K

    def initial_step(self, idisp, ivel):
        # initial time step
        p_fw = self.load_vec(self.tstart)
        p_0 = np.zeros(self.ndof_full)

        normal_force, force_s_n_mass, force_c, force_s_n = self.normalforce(idisp, ivel, self.tstart)
        fric_torque = self.coulomb_friction(normal_force, force_s_n, idisp, ivel, 0, self.tstart)
        p_0[1:-1] = fric_torque
        #p_0[1:-1] = -10

        p_0[0] = p_fw[0]-sum(fric_torque)
        p_0[-1] = p_fw[-1]

        if self.torsionCase is 'static':
            p_0 = np.delete(p_0, self.bc)
            #print(p_0)
        elif self.torsionCase is 'speed':
            omega_pri = 2*np.pi*self.omega/60
            p_0 = np.delete(p_0, self.bc)
            p_0[0] += self.struct_param[5]*omega_pri+self.struct_param[1]*omega_pri*self.tstart

        ddu_n = np.linalg.solve(self.J, -self.C.dot(ivel)-self.K.dot(idisp)+p_0)
        return ddu_n

    def solve_lin(self, idisp, ivel):
        # linear solver, not used for the friction model, Model 3

        ddu = np.zeros((self.ndof, self.ntstep))
        du = np.zeros((self.ndof, self.ntstep))
        u = np.zeros((self.ndof, self.ntstep))

        #ic = np.bmat('idisp,ivel')
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[:, 0] = self.initial_step(idisp, ivel)

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1] - t[0]

        for i in range(1, self.ntstep):
            p_fw = self.load_vec(t[i])
            p_i = np.zeros(7)
            p_i[0] = p_fw[0]
            p_i[-1] = p_fw[-1]

            mat_lhs = self.J + dt*self.gamma*self.C + dt**2*self.beta*self.K
            mat_rhs = p_i - self.C.dot(du[:, i-1]+dt*(1-self.gamma)*ddu[:, i-1]) - self.K.dot(
                u[:, i-1]+dt*du[:, i-1]+dt**2/2*(1-2*self.beta)*ddu[:, i-1])
            # if i == 1: print(mat_rhs)
            ddu[:, i] = np.linalg.solve(mat_lhs, mat_rhs)
            du[:, i] = du[:, i-1] + dt*((1-self.gamma)*ddu[:, i-1]+self.gamma*ddu[:, i])
            u[:, i] = u[:, i-1] + dt*du[:, i-1] + dt**2/2*((1-2*self.beta)*ddu[:, i-1] + 2*self.beta*ddu[:, i])

        return u, du, ddu

    def solve_nl(self, idisp, ivel):
        # The nonlinear solver used to solve the problem using the Newmark-beta method and Newton's method (fsolve)

        error = np.zeros((self.ndof, self.ntstep))
        ddu = np.zeros((self.ndof, self.ntstep))
        du = np.zeros((self.ndof, self.ntstep))
        u = np.zeros((self.ndof, self.ntstep))

        # Initial parameters
        idisp = np.delete(idisp, self.bc)
        ivel = np.delete(ivel, self.bc)
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[:, 0] = self.initial_step(idisp, ivel)  # computes the acc. for the initial time step

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1]-t[0]

        fric_torque = np.zeros(self.ntstep)                             # init friction torque (sum of all masses) vec.
        fric_force_comp = np.zeros((self.ndof_full-2, self.ntstep))     # init a vec. for the normal forces from the spring compression force
        fric_force_cent = np.zeros((self.ndof_full-2, self.ntstep))     # init a vec. for the normal forces from the centripetal force
        fric_bearing = np.zeros(self.ntstep)                            # init a vec. for the friction at the bearing between the DMF, NOT USED
        for i in range(1, self.ntstep):
            # problem solved with Newmark-beta and Newton's method
            u[:, i] = fsolve(self.func2, u[:, i-1], (u[:, i-1], du[:, i-1], ddu[:, i-1], t[i], dt), xtol=1*10**(-11))

            ddu[:, i] = (1 / (2 * self.beta)) * ((u[:, i] - u[:, i-1] - dt*du[:, i-1]) * (2 / (dt ** 2)) - (1 - 2 * self.beta) * ddu[:, i-1])
            du[:, i] = du[:, i-1] + ((1 - self.gamma) * ddu[:, i-1] + self.gamma * ddu[:, i]) * dt
            error[:, i] = self.func2(u[:, i], u[:, i-1], du[:, i-1], ddu[:, i-1], t[i], dt)

            # stores the frictional torques, forces and normal forces etc, used to plot in the main script
            fric_torque[i] = sum(self.get_load(t[i], u[:, i], du[:, i], ddu[:, i])[1])
            fric_bearing[i] = self.lugre_friction(u[:, i], du[:, i])
            fric_force_comp[:, i] = self.normalforce(u[:, i], du[:, i], t[i])[1]
            fric_force_cent[:, i] = self.normalforce(u[:, i], du[:, i], t[i])[2]

        return u, du, ddu, error, fric_torque, fric_bearing, fric_force_comp, fric_force_cent

    def load_vec(self, t):
        # this function computes the torque from the engine applied on the primary flywheel and the torque on the the secondary flywheel
        # from an applied angular displacement on the input shaft of the gearbox.
        freq = self.omega*3/60*2*np.pi

        # the angular displacement applied (sine load) on the input shaft of the gearbox was set to an amplitude of 10 degrees
        if self.torsionCase is 'static':
            #theta_gear = 30*np.pi/180*np.sin(2*np.pi*t)
            #dtheta_gear = np.pi**2/3*np.cos(2*np.pi*t)
            theta_gear = 10*np.pi/180*np.sin(2*np.pi*t)
            dtheta_gear = (1/9)*np.pi**2*np.cos(2*np.pi*t)

            t_gear = self.struct_param[4] * dtheta_gear + self.struct_param[2] * theta_gear
        elif self.torsionCase is 'speed':
            theta_gear = freq/3*t
            dtheta_gear = freq/3
            t_gear = self.struct_param[4]*dtheta_gear+self.struct_param[2]*theta_gear + self.meanload+self.ampload*np.sin(self.omegaload*t)   #2*np.pi

        t_eng = self.torq_mean + self.torq_amp*np.sin(freq*t)

        return np.array([t_eng, t_gear])

    def eigen_freq(self):
        J, C, K = NewmarkBeta.initialize_newmark(self)
        return eig(K, J)

    def get_number_timesteps(self):
        eigen_v = NewmarkBeta.eigen_freq(self)
        omega_max = np.sqrt(np.max(eigen_v[0].real))
        h_crit = 2/omega_max
        return 1/h_crit

    def get_load(self, t, u, du, ddu):
        # this function will create the full load vector including the frictional torque and reduce the vector due to the BC's

        torque_rhs = np.zeros(self.ndof_full)   # init the torque vector

        freq = self.omega*3/60*2*np.pi
        t_eng = np.array([self.torq_mean+self.torq_amp*np.sin(freq*t)])  # torque from the engine, sine load used

        # the angular displacement applied (sine load) on the input shaft of the gearbox was set to an amplitude of 10 degrees
        if self.torsionCase is 'static':
            #theta_gear = 30*np.pi/180*np.sin(2*np.pi*t)
            #dtheta_gear = np.pi**2/3*np.cos(2*np.pi*t)

            theta_gear = 10*np.pi/180*np.sin(2*np.pi*t)
            dtheta_gear = (1/9)*np.pi**2*np.cos(2*np.pi*t)

            t_gear = self.struct_param[4] * dtheta_gear + self.struct_param[2] * theta_gear
        elif self.torsionCase is 'speed':
            theta_gear = freq/3*t
            dtheta_gear = freq/3
            t_gear = self.struct_param[4] * dtheta_gear + self.struct_param[2] * theta_gear + self.meanload+self.ampload*np.sin(self.omegaload*t)   #2*np.pi

        # adds the frictional torques
        normal_force, force_s_n_mass, force_c, force_s_n = self.normalforce(u, du, t)
        fric_torque = self.coulomb_friction(normal_force, force_s_n, u, du, ddu, t)
        torque_rhs[2:-1] = fric_torque[1:]

        # the contribution to the primary and the secondary flywheel
        torque_rhs[0] = t_eng - sum(fric_torque)
        torque_rhs[-1] = t_gear #+ bearing_friction      # gearbox torque and friction torque from bearing

        # reduces the load vector based on the BC's
        if self.torsionCase is 'static':
            torque_rhs = np.delete(torque_rhs, self.bc)
            torque_rhs[0] += -sum(fric_torque[1:]) + self.struct_param[5]*du[1]+self.struct_param[1]*u[1]
            #print(torque_rhs)
        elif self.torsionCase is 'speed':
            torque_rhs = np.delete(torque_rhs, self.bc)
            torque_rhs[0] += - sum(fric_torque[1:])
            #torque_rhs[0] += self.model_param[5]*freq/3+self.model_param[1]*(freq/3)*t

        return torque_rhs, fric_torque

    def func2(self, u_i, u_old, du_old, ddu_old, t, h):
        ddu_i = 1/(2*self.beta)*((u_i-u_old-h*du_old)*2/h**2-(1-2*self.beta)*ddu_old)
        du_i = du_old+((1-self.gamma)*ddu_old+self.gamma*ddu_i)*h
        p_i = self.get_load(t, u_i, du_i, ddu_i)[0]

        # self.jmat().dot(ddu_i) + self.c_nl(u_i).dot(du_i) + self.k_nl(u_i).dot(u_i) - p_i
        return self.J.dot(ddu_i)+self.C.dot(du_i)+self.K.dot(u_i)-p_i

    def normalforce(self, u, du, t):
        # In this function the normal forces that will act on the arc-spring masses are computed
        force_s_n = np.zeros(self.ndof_full-1)          # init radial force vec. from spring compression
        force_s_n_mass = np.zeros(self.ndof_full-2)     # init radial force vec. from spring compression the sum of one mass
        force_c = np.zeros(self.ndof_full-2)            # init radial force vec. from centripetal force

        if self.torsionCase is 'static':
            u_loc = np.zeros(self.ndof_full)
            du_loc = np.zeros(self.ndof_full)
            u_loc[1::] = u
            du_loc[1::] = du
        elif self.torsionCase is 'speed':
            u_loc = np.zeros(self.ndof_full)
            du_loc = np.zeros(self.ndof_full)
            u_loc[0] = 2*np.pi*self.omega/60*t
            du_loc[0] = 2*np.pi*self.omega/60
            u_loc[1::] = u
            du_loc[1::] = du

        for i in range(1, self.ndof_full):
            force_s_n[i-1] = self.struct_param[1]/self.gp[1]*(u_loc[i-1]-u_loc[i])*np.sin((self.gp[-1]-abs(u_loc[i-1]-u_loc[i]))/2)
        for i in range(1, self.ndof_full-1):
            force_s_n_mass[i-1] = force_s_n[i-1]+force_s_n[i]
            force_c[i-1] = (self.gp[0]/(self.ndof-2))*self.gp[1]*du_loc[i]**2    # centrifugal force

        normal_force = force_c + force_s_n_mass

        return normal_force, force_s_n_mass, force_c, force_s_n

    def coulomb_friction(self, normal_force, force_s_n, u, du, ddu, t):
        friction_torque = np.zeros(self.ndof - 2)

        if self.torsionCase is 'static':
            u_loc = np.zeros(self.ndof_full)
            du_loc = np.zeros(self.ndof_full)
            ddu_loc = np.zeros(self.ndof_full)
            u_loc[1::] = u
            du_loc[1::] = du
            ddu_loc[1::] = ddu
        elif self.torsionCase is 'speed':
            u_loc = np.zeros(self.ndof_full)
            du_loc = np.zeros(self.ndof_full)
            ddu_loc = np.zeros(self.ndof_full)
            u_loc[0] = 2 * np.pi * self.omega/60*t
            du_loc[0] = 2*np.pi*self.omega/60
            u_loc[1::] = u
            du_loc[1::] = du
            ddu_loc[1::] = ddu

        # The frictional torques for the arc-spring masses were computed using the inverse tangent function with a argument of 10 times the relative angular velocity (hard-coded)
        for i in range(1, self.ndof_full-1):
            friction_torque[i-1] = ((self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1]))/(np.pi/2))*np.arctan(10*(du_loc[0]-du_loc[i]))

        return friction_torque

    def lugre_friction(self, u, du):
        # LuGre friction model was implemented but not used in the model
        sigma_0 = 573  # [Nm/rad]
        sigma_1 = 1    # [Nms/rad]
        sigma_2 = 2.8  # [Nms/rad]
        max_fric_torque = 5  # [Nm]

        #friction_force = normal_force*self.gp[5]  # multiplied with the friction coefficient
        dtheta = u[0]-u[-1]
        dv = du[0]-du[-1]
        ddtheta = dv-sigma_0/max_fric_torque*abs(dv)*dtheta
        bearing_friction = sigma_0*dtheta + sigma_1*ddtheta + sigma_2*dv

        return bearing_friction

class DMFModel:
    def __init__(self, model_nr, bc, torsionCase):
        self.gp, self.struct_param = self.dmf_param(model_nr)

        self.ndof_arc = int(self.gp[7])
        self.nof_springs = self.ndof_arc+1

        self.bc = bc
        self.torsionCase = torsionCase

    @staticmethod
    def dmf_param(model_nr):
        # this function reads the CSV file with the structural-, geometrical- and physical parameters and the number of arc-spring masses
        filename = 'data/geometry/DMF_StructParam.csv'
        f = open(filename)
        lines = f.readlines()
        f.close()
        data = []
        for line in lines:
            data.append(line.split(';'))
        data = np.array(data)

        # parameter_name = data[1::, 0]
        parameter_value = np.array(data[model_nr, :], float)

        j_pri = parameter_value[0]
        j_sec = parameter_value[1]
        # m = parameter_value[2]
        m_spring = parameter_value[3]
        r_spring = parameter_value[4]
        k_spring = parameter_value[5]
        k_axle = parameter_value[6]
        c1 = parameter_value[7]
        c2 = parameter_value[8]
        mu = parameter_value[9]
        d_spring = parameter_value[10]
        dof_arcspring = parameter_value[11]
        len_spring = np.pi/(dof_arcspring+1)

        j_spring = m_spring*r_spring**2

        k_spring_elem = k_spring*(dof_arcspring+1)
        c_spring_elem = c1*(dof_arcspring+1)
        #print(c_spring_elem)
        #print(k_spring_elem)

        return [m_spring, r_spring, j_spring, j_pri, j_sec, mu, d_spring, dof_arcspring, len_spring], [k_spring, k_spring_elem, k_axle, c1, c2, c_spring_elem]

    def model_assem(self,u,du):
        # this function assembles and returns the matrices, J, C, K for the number of arc-spring masses stated in the CSV file
        j_i = self.gp[2]/self.ndof_arc
        j_mat = np.diag(np.array([self.gp[3]] + [j_i]*self.ndof_arc + [self.gp[4]]))

        # TODO: Add condition if multistage!
        k_spring_elem = self.struct_param[1]
        k_axle = self.struct_param[2]
        # TODO: Damping non linearity's added as force???
        c_spring = self.struct_param[3]*self.nof_springs
        c_axle = self.struct_param[4]
        k_vec = np.array([0] + [k_spring_elem] * self.nof_springs + [k_axle])
        c_vec = np.array([0] + [c_spring] * self.nof_springs + [c_axle])

        # Serial springs only!
        k_mat = np.zeros((self.ndof_arc+2, self.ndof_arc+2))
        c_mat = np.zeros((self.ndof_arc+2, self.ndof_arc+2))

        k_mat[0, 0] += k_vec[0]
        k_mat[-1, -1] += k_vec[-1]
        c_mat[0, 0] += c_vec[0]
        c_mat[-1, -1] += c_vec[-1]

        # Assemble stiffness and damping matrices
        for i in range(0, self.nof_springs):
            k_e = np.array([[k_vec[i + 1], -k_vec[i + 1]], [-k_vec[i + 1], k_vec[i + 1]]])
            c_e = np.array([[c_vec[i + 1], -c_vec[i + 1]], [-c_vec[i + 1], c_vec[i + 1]]])

            k_mat[i:i+2, i:i+2] += k_e
            c_mat[i:i+2, i:i+2] += c_e

        #if self.torsionCase is 'static':
        j_mat = np.delete(np.delete(j_mat, self.bc, axis=0), self.bc, axis=1)
        c_mat = np.delete(np.delete(c_mat, self.bc, axis=0), self.bc, axis=1)
        k_mat = np.delete(np.delete(k_mat, self.bc, axis=0), self.bc, axis=1)

        return j_mat, c_mat, k_mat







