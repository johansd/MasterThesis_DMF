from FrictionModel_TorqueResp_lib import *
import numpy as np
import matplotlib.pyplot as plt
import time

# This script was used to compute the torque response of the DMF for mainly the standstill case ('static') of the primary flywheel. The dynamic case ('speed')
# was implemented but will be a future work.

# INPUT
torsionCase = 'static'   #'static' , 'speed'
speed = np.array([2000])
torq = np.array([3000, 2000])     # [3000, 2000], [300, 500]

if torsionCase is 'static':
    # standstill case
    bc = np.array([0])  # sets the primary flywheel fix
    plot_time = 0.9
    tstart = 0
    tend = 10
    ntstep = 1000
    omegaload = 1
    meanload = 1
    ampload = 1
elif torsionCase is 'speed':
    # dynamic case
    bc = np.array([0])  # primary flywheel speed constant
    speedload = 2000
    freqload = speedload/60*3
    omegaload = freqload*2*np.pi
    meanload = 0
    ampload = 300
    ntstep = 50000
    periodtime = 1/freqload
    tstart = 0
    tend = 10
    plot_time = 0.999
    #plot_time = 1-periodtime
    #print(plot_time)

# these structural parameters are not used, the one used are readed from a CSV file
j = np.array([1.8, 0.6])
k = np.array([20000, 1100])
c = np.array([300, 10])

taccur = 5

# Newmark-beta parameters
beta = 1/4
gamma = 1/2

speed_legend = []
i = 0
for rpm in speed:
    start = time.time()
    i += 1
    print('rpm:')
    print(rpm, '\n')
    omega = 2*np.pi*rpm/60

    NBhandle = NewmarkBeta(j, c, k, rpm, omegaload, ampload, meanload, [tstart, tend], ntstep, torq, taccur, beta, gamma, torsionCase, bc)

    ndof = int(NBhandle.ndof_full)

    # initial conditions
    idisp = np.array([0]*ndof)
    if torsionCase is 'static':
        ivel = np.array([0]*ndof)
    elif torsionCase is 'speed':
        ivel = np.array([omega]*ndof)

    # solves the problem using Newmark-beta and Newton's method
    u, du, ddu, error, fric_torque, fric_bearing, fric_force_comp, fric_force_cent = NBhandle.solve_nl(idisp, ivel)

    end = time.time()

    print('Simulation '+str(i)+' time:')
    print(str(end-start)+' s')

    speed_legend.append(str(rpm) + ' rpm')
    t = np.linspace(NBhandle.tstart, NBhandle.tend, NBhandle.ntstep)
    disp_pri = omega*t

    print('angular displacement')
    print(min(disp_pri-u[-1, :]))
    print(max(disp_pri-u[-1, :]))

    print('frictional torque')
    print(min(fric_torque))
    print(max(fric_torque))

    # computes the torque response of the DMF
    if torsionCase is 'static':
        Torque_sec = u[-1, :]*NBhandle.model_param[0]+du[-1, :]*NBhandle.model_param[3]-fric_torque
    elif torsionCase is 'speed':
        Torque_sec = (u[-1, :]-disp_pri)*NBhandle.model_param[0]+(du[-1, :]-omega)*NBhandle.model_param[3]- fric_torque

    # Torque response plots
    if torsionCase is 'static':
        # plot the torque response for the standstill case
        plt.figure(1)
        plt.plot(u[-1, plot_time*NBhandle.ntstep-1:], Torque_sec[plot_time*NBhandle.ntstep-1:])
        #plt.plot(u[-1, :], Torque_sec)
        plt.xlabel(r'$\theta_{sec}(t)-\theta_{pri}(t)$' ' [rad]')
        plt.ylabel('Torque [Nm]')
        plt.text(0.065, 1100, '1')
        plt.text(0.18, 2100, '2')
        plt.text(0.075, 600, '3')
        plt.text(-0.08, -1350, '4')
        plt.text(-0.185, -2200, '5')
        plt.text(-0.09, -800, '6')
        plt.grid()
        plt.savefig('figures/figTransmTorq.png', dpi=300)
        #plt.legend(speed_legend)
    elif torsionCase is 'speed':
        # plot the torque response for the dynamic case
        plt.figure(1)
        #plt.plot(u[-1, plot_time*NBhandle.ntstep-1:]-disp_pri[plot_time*NBhandle.ntstep-1:], Torque_sec[plot_time*NBhandle.ntstep-1:])
        plt.plot(u[-1, 0:plot_time*NBhandle.ntstep]-disp_pri[0:plot_time*NBhandle.ntstep], Torque_sec[0:plot_time*NBhandle.ntstep])
        #plt.plot(u[-1, :]-disp_pri, Torque_sec)
        plt.xlabel(r'$\theta_{pri}(t)-\theta_{sec}(t)$' ' [rad]')
        plt.ylabel('Torque [Nm]')
        plt.grid()
        plt.savefig('figures/figTransmTorq.png', dpi=300)
        # plt.legend(speed_legend)
        #disp_pri[plot_time * NBhandle.ntstep:]


'''
print('Egienvalues')
#print(NBhandle.eigen_freq()[0])
print(np.sqrt(NBhandle.eigen_freq()[0][:].real)/(2*np.pi*3)*60)
'''

plt.show()




