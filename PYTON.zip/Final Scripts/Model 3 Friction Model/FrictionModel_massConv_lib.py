import numpy as np
from scipy.linalg import *
from scipy.optimize import fsolve
from scipy import sparse
import math
import time

class NewmarkBeta:
    def __init__(self, j, c, k, eng_freq, ti, ntstep, torq, accuracy, beta, gamma, nmasses):
        self.beta = beta
        self.gamma = gamma
        self.acc = accuracy
        self.tstart = ti[0]
        self.tend = ti[1]
        self.inert = j
        self.damp = c
        self.stiff = k
        self.omega = eng_freq
        #self.ntstep = int(math.ceil((self.tend - self.tstart)*self.get_number_timesteps()*self.acc/100)*100)
        self.ntstep = ntstep
        self.torq_mean = torq[0]
        self.torq_amp = torq[1]
        self.nmasses = nmasses

        # The input is 1 since the second row in the CSV is read and used (hard-coded)
        self.gp, self.struct_param = DMFModel(1, self.nmasses).dmf_param(1, self.nmasses)
        self.J, self.C, self.K = DMFModel(1, self.nmasses).model_assem(1, 1)

        self.ndof = self.J.shape[0]

    def initialize_newmark(self):
        J, C, K = DMFModel(1, self.nmasses).model_assem(1, 1)
        return J, C, K

    def initial_step(self, idisp, ivel):
        # initial time step
        p_fw = self.load_vec(self.tstart)
        p_0 = np.zeros(self.ndof)

        ddu_ini = np.zeros(self.ndof)

        normal_force, force_s_n_mass, force_c, force_s_n = self.normalforce(idisp, ivel)
        fric_torque = self.coulomb_friction(normal_force, force_s_n, idisp, ivel, ddu_ini)
        p_0[1:-1] = fric_torque
        #p_0[1:-1] = -10

        p_0[0] = p_fw[0] - sum(fric_torque)
        p_0[-1] = p_fw[-1]

        ddu_n = np.linalg.solve(self.J, -self.C.dot(ivel)-self.K.dot(idisp)+p_0)
        return ddu_n

    def solve_lin(self, idisp, ivel):
        # linear solver, not used for the friction model, Model 3

        ddu = np.zeros((self.ndof, self.ntstep))
        du = np.zeros((self.ndof, self.ntstep))
        u = np.zeros((self.ndof, self.ntstep))

        #ic = np.bmat('idisp,ivel')
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[:, 0] = self.initial_step(idisp, ivel)

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1] - t[0]

        for i in range(1, self.ntstep):
            p_fw = self.load_vec(t[i])
            p_i = np.zeros(7)
            p_i[0] = p_fw[0]
            p_i[-1] = p_fw[-1]

            mat_lhs = self.J + dt*self.gamma*self.C + dt**2*self.beta*self.K
            mat_rhs = p_i - self.C.dot(du[:, i-1]+dt*(1-self.gamma)*ddu[:, i-1]) - self.K.dot(
                u[:, i-1]+dt*du[:, i-1]+dt**2/2*(1-2*self.beta)*ddu[:, i-1])
            # if i == 1: print(mat_rhs)
            ddu[:, i] = np.linalg.solve(mat_lhs, mat_rhs)
            du[:, i] = du[:, i-1] + dt*((1-self.gamma)*ddu[:, i-1]+self.gamma*ddu[:, i])
            u[:, i] = u[:, i-1] + dt*du[:, i-1] + dt**2/2*((1-2*self.beta)*ddu[:, i-1] + 2*self.beta*ddu[:, i])

        return u, du, ddu

    def solve_nl(self, idisp, ivel):
        # The nonlinear solver used to solve the problem using the Newmark-beta method and Newton's method (fsolve)

        error = np.zeros((self.ndof, self.ntstep))
        ddu = np.zeros((self.ndof, self.ntstep))
        du = np.zeros((self.ndof, self.ntstep))
        u = np.zeros((self.ndof, self.ntstep))

        # Initial parameters
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[:, 0] = self.initial_step(idisp, ivel)  # computes the acc. for the initial time step

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1]-t[0]

        fric_torque = np.zeros(self.ntstep)                         # init friction torque (sum of all masses) vec.
        fric_force = np.zeros((self.ndof-2, self.ntstep))           # init friction force vec.
        fric_torque_all = np.zeros((self.ndof-2, self.ntstep))      # init friction torque (for all masses) vec.
        fric_force_comp = np.zeros((self.ndof-2, self.ntstep))      # init a vec. for the normal forces from the spring compression force
        fric_force_cent = np.zeros((self.ndof-2, self.ntstep))      # init a vec. for the normal forces from the centripetal force
        fric_bearing = np.zeros(self.ntstep)                        # init a vec. for the friction at the bearing between the DMF, NOT USED
        for i in range(1, self.ntstep):
            # problem solved with Newmark-beta and Newton's method
            u[:, i] = fsolve(self.func2, u[:, i-1], (u[:, i-1], du[:, i-1], ddu[:, i-1], t[i], dt), xtol=1*10**(-11))
            ddu[:, i] = (1 / (2 * self.beta)) * ((u[:, i] - u[:, i-1] - dt*du[:, i-1]) * (2 / (dt ** 2)) - (1 - 2 * self.beta) * ddu[:, i-1])
            du[:, i] = du[:, i-1] + ((1 - self.gamma) * ddu[:, i-1] + self.gamma * ddu[:, i]) * dt
            error[:, i] = self.func2(u[:, i], u[:, i-1], du[:, i-1], ddu[:, i-1], t[i], dt)

            # stores the frictional torques, forces and normal forces etc, used to plot in the main script
            fric_torque[i] = sum(self.get_load(t[i], u[:, i], du[:, i], ddu[:, i])[1:-1])
            fric_force[:, i] = self.get_load(t[i], u[:, i], du[:, i], ddu[:, i])[1:-1]/(self.gp[1]+self.gp[6]/2)
            fric_torque_all[:, i] = self.get_load(t[i], u[:, i], du[:, i], ddu[:, i])[1:-1]
            fric_bearing[i] = self.lugre_friction(u[:, i], du[:, i])

            fric_force_comp[:, i] = self.normalforce(u[:, i], du[:, i])[1]
            fric_force_cent[:, i] = self.normalforce(u[:, i], du[:, i])[2]

        return u, du, ddu, error, fric_torque, fric_torque_all, fric_force, fric_bearing, fric_force_comp, fric_force_cent

    def load_vec(self, t):
        freq = self.omega * 3 / 60 * 2 * np.pi
        t_gear = self.damp[1] * freq / 3 + self.stiff[1] * freq / 3 * t
        return np.array([self.torq_mean + self.torq_amp*np.sin(freq * t), t_gear])

    def eigen_freq(self):
        J, C, K = NewmarkBeta.initialize_newmark(self)
        return eig(K, J)

    def get_number_timesteps(self):
        eigen_v = NewmarkBeta.eigen_freq(self)
        omega_max = np.sqrt(np.max(eigen_v[0].real))
        h_crit = 2/omega_max
        return 1/h_crit

    def get_load(self, t, u, du, ddu):
        # In this function the torque vector is created and the frictional torque is added
        torque_rhs = np.zeros(self.ndof)    # init the torque vector

        freq = self.omega * 3 / 60 * 2 * np.pi
        t_eng = np.array([self.torq_mean + self.torq_amp * np.sin(freq * t)])           # torque from the engine, sine load used
        t_gear = self.struct_param[4] * freq / 3 + self.struct_param[2] * freq / 3 * t  # torque from the input shaft of the gearbox

        # frictional torque
        normal_force, force_s_n_mass, force_c, force_s_n = self.normalforce(u, du)
        fric_torque = self.coulomb_friction(normal_force, force_s_n, u, du, ddu)
        torque_rhs[1:-1] = fric_torque  # the frictional torques are added to the full torque vector

        # the contribution to the primary and the secondary flywheel
        torque_rhs[0] = t_eng - sum(fric_torque)
        torque_rhs[-1] = t_gear

        return torque_rhs

    def func2(self, u_i, u_old, du_old, ddu_old, t, h):
        ddu_i = 1/(2*self.beta)*((u_i-u_old-h*du_old)*2/h**2-(1-2*self.beta)*ddu_old)
        du_i = du_old+((1-self.gamma)*ddu_old+self.gamma*ddu_i)*h
        p_i = self.get_load(t, u_i, du_i, ddu_i)

        # self.jmat().dot(ddu_i) + self.c_nl(u_i).dot(du_i) + self.k_nl(u_i).dot(u_i) - p_i
        return self.J.dot(ddu_i)+self.C.dot(du_i)+self.K.dot(u_i)-p_i

    def normalforce(self, u, du):
        # In this function the normal forces that will act on the arc-spring masses are computed
        force_s_n = np.zeros(self.ndof-1)           # init radial force vec. from spring compression
        force_s_n_mass = np.zeros(self.ndof-2)      # init radial force vec. from spring compression the sum of one mass
        force_c = np.zeros(self.ndof-2)             # init radial force vec. from centripetal force

        for i in range(1, self.ndof):
            force_s_n[i-1] = self.struct_param[1]/self.gp[1]*(u[i-1]-u[i])*np.sin((self.gp[-1]-(u[i-1]-u[i]))/2)

        for i in range(1, self.ndof-1):
            force_s_n_mass[i-1] = force_s_n[i-1]+force_s_n[i]
            force_c[i-1] = (self.gp[0]/(self.ndof-2))*self.gp[1]*du[i]**2    # centrifugal force
            #print(force_c)

        #normal_force = abs(force_c) + abs(force_n)  # normal force for the spring mass element

        normal_force = force_c + force_s_n_mass

        return normal_force, force_s_n_mass, force_c, force_s_n

    def coulomb_friction(self, normal_force, force_s_n, u, du, ddu):
        friction_torque = np.zeros(self.ndof-2)

        '''
        # This was a test to implement a standstill behaviour of the arc-spring, not used in the modelling

        relvel = np.zeros(self.ndof-2)
        for i in range(1, self.ndof-1):
            relvel[i-1] = du[0]-du[i]

        for i in range(1, self.ndof-1):
            frictorq = self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1])
            #frictorq = abs(((self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1]))/(np.pi/2))*np.arctan(10*relvel[i-1]))
            torq_si = self.gp[2]*(ddu[0]-ddu[i])-self.model_param[1]*((u[i-1]-u[i])-(u[i]-u[i+1]))     # /self.gp[1]

            if relvel[i-1] < 0.5 and abs(torq_si) <= frictorq:    #relvel[i-1] < 0.5 and
                relvel[i-1] = 0
                #self.du[i, self.tstep] = du[0]

            if relvel[i-1] == 0 and abs(torq_si) <= frictorq:
                friction_torque[i-1] = torq_si

            elif relvel[i-1] == 0 and abs(torq_si) > frictorq:
                friction_torque[i-1] = self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1])*np.sign(torq_si)
                #friction_torque[i-1] = ((self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1]))/(np.pi/2))*np.arctan(10*torq_si)

            else:
                friction_torque[i-1] = self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1])*np.sign(relvel[i-1]) #*(-1)   #du[0]-
                #friction_torque[i-1] = ((self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1]))/(np.pi/2))*np.arctan(10*relvel[i-1])

            #print(friction_torque)
        '''
        # The frictional torques for the arc-spring masses were computed using the inverse tangent function with a argument of 10 times the relative angular velocity (hard-coded)
        for i in range(1, self.ndof-1):
            friction_torque[i-1] = ((self.gp[5]*(self.gp[1]+self.gp[6]/2)*abs(normal_force[i-1]))/(np.pi/2))*np.arctan(10*(du[0]-du[i]))

        return friction_torque

    def lugre_friction(self, u, du):
        # LuGre friction model was implemented but not used in the model
        sigma_0 = 573  # [Nm/rad]
        sigma_1 = 1    # [Nms/rad]
        sigma_2 = 2.8  # [Nms/rad]
        max_fric_torque = 5  # [Nm]

        #friction_force = normal_force*self.gp[5]  # multiplied with the friction coefficient

        dtheta = u[0]-u[-1]
        dv = du[0]-du[-1]
        ddtheta = dv-sigma_0/max_fric_torque*abs(dv)*dtheta

        bearing_friction = sigma_0*dtheta + sigma_1*ddtheta + sigma_2*dv

        return bearing_friction


class DMFModel:
    def __init__(self, model_nr, nmasses):
        self.gp, self.struct_param = self.dmf_param(model_nr, nmasses)

        self.ndof_arc = int(self.gp[7])
        self.nof_springs = self.ndof_arc+1

    @staticmethod
    def dmf_param(model_nr, nmasses):
        # this function reads the CSV file with the structural-, geometrical- and physical parameters and the number of arc-spring masses
        filename = 'data/geometry/DMF_StructParam.csv'
        f = open(filename)
        lines = f.readlines()
        f.close()
        data = []
        for line in lines:
            data.append(line.split(';'))
        data = np.array(data)

        # parameter_name = data[1::, 0]
        parameter_value = np.array(data[model_nr, :], float)

        j_pri = parameter_value[0]
        j_sec = parameter_value[1]
        # m = parameter_value[2]
        m_spring = parameter_value[3]
        r_spring = parameter_value[4]
        k_spring = parameter_value[5]
        k_axle = parameter_value[6]
        c1 = parameter_value[7]
        c2 = parameter_value[8]
        mu = parameter_value[9]
        d_spring = parameter_value[10]
        #dof_arcspring = parameter_value[11]
        dof_arcspring = nmasses
        len_spring = np.pi/(dof_arcspring+1)

        j_spring = m_spring*r_spring**2

        k_spring_elem = k_spring*(dof_arcspring+1)
        #print(k_spring_elem)

        return [m_spring, r_spring, j_spring, j_pri, j_sec, mu, d_spring, dof_arcspring, len_spring], [k_spring, k_spring_elem, k_axle, c1, c2]

    def model_assem(self,u,du):
        # this function assembles and returns the matrices, J, C, K for the number of arc-spring masses stated in the CSV file
        j_i = self.gp[2]/self.ndof_arc
        j_mat = np.diag(np.array([self.gp[3]] + [j_i]*self.ndof_arc + [self.gp[4]]))

        # TODO: Add condition if multistage!
        k_spring_elem = self.struct_param[1]
        k_axle = self.struct_param[2]
        # TODO: Damping non linearity's added as force???
        c_spring = self.struct_param[3]*self.nof_springs
        c_axle = self.struct_param[4]
        k_vec = np.array([0] + [k_spring_elem] * self.nof_springs + [k_axle])
        c_vec = np.array([0] + [c_spring] * self.nof_springs + [c_axle])

        # Serial springs only!
        k_mat = np.zeros((self.ndof_arc+2, self.ndof_arc+2))
        c_mat = np.zeros((self.ndof_arc+2, self.ndof_arc+2))

        k_mat[0, 0] += k_vec[0]
        k_mat[-1, -1] += k_vec[-1]
        c_mat[0, 0] += c_vec[0]
        c_mat[-1, -1] += c_vec[-1]

        # Assemble stiffness and damping matrices
        for i in range(0, self.nof_springs):
            k_e = np.array([[k_vec[i+1], -k_vec[i+1]], [-k_vec[i+1], k_vec[i+1]]])
            c_e = np.array([[c_vec[i+1], -c_vec[i+1]], [-c_vec[i+1], c_vec[i+1]]])
            k_mat[i:i+2, i:i+2] += k_e
            c_mat[i:i+2, i:i+2] += c_e

        return j_mat, c_mat, k_mat







