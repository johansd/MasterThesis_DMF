from Model3FrictionModel_lib import *
import numpy as np
import matplotlib.pyplot as plt
import time
import csv

# This script was used to compute the response of the DMF for the frictional model (Model 3), that was used in the verification against the AVL model
# The library Model3FrictionModel_lib is called which uses Newmark-beta and Newton's method
# The structural parameters used were read from the CSV file, data/geometry/DMF_StructParam.csv

plot_time = 0.99

# INPUT
speed = np.array([800, 1400, 2000])     # engine speed
torq = np.array([3000, 2000])           # [3000, 2000], [300, 500], mean and amp. for the sine load

# these structural parameters are not used, the structural parameters used are read from a CSV file
j = np.array([1.8, 0.6])
k = np.array([20000, 11000])
c = np.array([300, 10])

tstart = 0
tend = 10
taccur = 10
ntstep = 50000

# Newmark-beta parameters
beta = 1/4
gamma = 1/2

speed_legend = []
mass_legend = []
mass_legend2 = []
rms_python = np.zeros(len(speed))   # vector that stores the RMS-values
speedrange = np.zeros(len(speed))
centforce_mean = np.zeros(len(speed))
compforce_mean = np.zeros(len(speed))
i = 0
linetype = ['b', 'g--', 'r:']
for rpm in speed:
    start = time.time()
    i += 1
    print('rpm:')
    print(rpm, '\n')
    omega = 2*np.pi*rpm/60

    NBhandle = NewmarkBeta(j, c, k, rpm, [tstart, tend], ntstep, torq, taccur, beta, gamma)

    ndof = int(NBhandle.ndof)
    idisp = np.array([0]*ndof)
    ivel = np.array([omega]*ndof)

    u, du, ddu, error, fric_torque, fric_torque_all, fric_force, fric_bearing, fric_force_comp, fric_force_cent = NBhandle.solve_nl(idisp, ivel)    # solves the problem using Newmark-beta and Newton's method

    end = time.time()

    print('Simulation '+str(i)+' time:')
    print(str(end-start)+' s', '\n')

    speed_legend.append(str(rpm) + ' rpm')
    t = np.linspace(tstart, tend, ntstep)

    # computes the torque in to the secondary flywheel and the input shaft of the gearbox
    Torque_sec = (u[0, :]-u[-1, :])*NBhandle.struct_param[0] + (du[0, :]-du[-1, :])*NBhandle.struct_param[3] - fric_torque
    Torque_is = (u[-1, :]-omega*t)*NBhandle.struct_param[2] + (du[-1, :]-omega)*NBhandle.struct_param[4]

    print('Mean Value disp')
    print(max(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:]) - ((max(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:])-min(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:]))/2), '\n')

    print('Range (2*Amplitude)')
    print(max(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:])-min(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:]))

    print('Mean Value Torque-Sec')
    print(max(Torque_sec[plot_time*ntstep:])-((max(Torque_sec[plot_time*ntstep:])-min(Torque_sec[plot_time*ntstep:]))/2))

    print('Amplitude Value Torque-Sec')
    print((max(Torque_sec[plot_time*ntstep:])-min(Torque_sec[plot_time*ntstep:]))/2)

    print('Mean Value Torque-Is')
    print(max(Torque_is[plot_time*ntstep:])-((max(Torque_is[plot_time*ntstep:])-min(Torque_is[plot_time*ntstep:]))/2))

    print('Amplitude Value Torque-Is')
    print((max(Torque_is[plot_time*ntstep:])-min(Torque_is[plot_time*ntstep:]))/2)

    print('Friction loss')
    print(fric_torque[plot_time*ntstep], '\n')

    rms_python[i-1] = np.sqrt(1/(0.1)*np.trapz(np.square(u[0, plot_time*ntstep-1:] - u[-1, plot_time*ntstep-1:]), t[plot_time*ntstep-1:]))
    print('RMS-Value')
    print(rms_python[i-1])

    speedrange[i-1] = max(u[0, plot_time*ntstep:] - u[-1, plot_time*ntstep:]) - min(u[0, plot_time*ntstep:]-u[-1, plot_time*ntstep:])

    centforce_mean[i-1] = np.mean(fric_force_cent[4, plot_time*ntstep:])
    compforce_mean[i-1] = np.mean(fric_force_comp[4, plot_time * ntstep:])

    # plots the angular displacement for the DMF (pri-sec)
    plt.figure(1)
    plt.plot(t[plot_time*ntstep:], u[0, plot_time * ntstep:] - u[-1, plot_time * ntstep:], linetype[i-1], linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel(r'$\theta_{pri}-\theta_{sec}$' ' [rad]')
    plt.grid()
    plt.legend(speed_legend)
    #plt.axis([9.9, 10, 0.215, 0.255])
    #plt.yticks(np.arange(0.16, 0.34, 0.02))
    plt.savefig('figures/figDisp.png', dpi=300)

    # plot the angular velocity for the DMF
    plt.figure(2)
    plt.plot(t[plot_time*ntstep:], du[0, plot_time * ntstep:] - du[5, plot_time * ntstep:], linetype[i-1], linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel(r'$\dot{\theta}_{pri}-\dot{\theta}_{1}$' ' [rad/s]')
    plt.grid()
    plt.legend(speed_legend)
    plt.savefig('figures/figVel.png', dpi=300)

    # plots the torque in to the secondary flywheel
    plt.figure(3)
    plt.plot(t[plot_time*ntstep:], Torque_sec[plot_time*ntstep:], linetype[i-1], linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('Torque [Nm]')
    plt.grid()
    plt.legend(speed_legend)
    plt.savefig('figures/figTsec.png', dpi=300)

    # plots the torque in to the input shaft of the gearbox
    plt.figure(4)
    plt.plot(t[plot_time*ntstep:], Torque_is[plot_time*ntstep:], linetype[i-1], linewidth=1.5)
    plt.xlabel('time [s]')
    plt.ylabel('Torque [Nm]')
    plt.grid()
    plt.legend(speed_legend)
    plt.savefig('figures/figTis.png', dpi=300)

    '''
    # plots for the frictional torque, frictional force and the normal forces for the different arc-spring masses

    for j in range(0, int(NBhandle.gp[7])):
        mass_legend.append('Mass: '+str(j+1))
        # plot the centripetal force for the arc-spring masses
        plt.figure(2)
        plt.plot(t[plot_time*ntstep:], fric_force_cent[j, plot_time*ntstep:])
        plt.xlabel('time [s]')
        plt.ylabel('centripetal force [N]')
        plt.grid()
        plt.legend(mass_legend)
        plt.savefig('figures/fig1.png', dpi=300)

        # plot the spring compression force for the masses
        plt.figure(3)
        plt.plot(t[plot_time*ntstep:], fric_force_comp[j, plot_time*ntstep:])
        plt.xlabel('time [s]')
        plt.ylabel('spring compression force [N]')
        plt.grid()
        plt.legend(mass_legend)
        plt.savefig('figures/fig2.png', dpi=300)

        # plot the spring compression force + centripetal force for the masses
        #plt.figure(6, dpi=300)
        plt.plot(t[plot_time*ntstep:], fric_force_comp[j, plot_time*ntstep:]+fric_force_cent[j, plot_time*ntstep:])
        plt.xlabel('time [s]')
        plt.ylabel('spring compression + cent. force [N]')
        plt.grid()
        plt.legend(mass_legend)
        plt.savefig('figures/fig3.png', dpi=300)

        # plots the friction force for all the masses
        plt.figure(5)
        plt.plot(t[plot_time*ntstep:], fric_force[j, plot_time*ntstep:])
        plt.xlabel('time [s]')
        plt.ylabel('Friction force [N]')
        plt.grid()
        plt.legend(mass_legend)
        plt.savefig('figures/fig4.png', dpi=300)

        # plots the friction torque for all the masses
        plt.figure(6)
        plt.plot(t[plot_time*ntstep:], fric_torque_all[j, plot_time*ntstep:])
        plt.xlabel('time [s]')
        plt.ylabel('Friction torque [Nm]')
        plt.grid()
        plt.legend(mass_legend)
        plt.savefig('figures/fig5.png', dpi=300)

        # plot the friction force for mass 4 and 5
        if j > 2:
            mass_legend2.append('Mass: ' + str(j + 1))
            plt.figure(7)
            plt.plot(t[plot_time*ntstep:], fric_force[j, plot_time*ntstep:])
            plt.xlabel('time [s]')
            plt.ylabel('Friction force [N]')
            plt.grid()
            plt.legend(mass_legend2)
            plt.savefig('figures/fig6.png', dpi=300)
    '''


print('Egienvalues')
#print(NBhandle.eigen_freq()[0])
print(np.sqrt(NBhandle.eigen_freq()[0][:].real)/(2*np.pi*3)*60)

plt.show()




