from FlywheelTorque_lib3 import *
import numpy as np
from scipy.linalg import *
from scipy.optimize import fsolve
import math

class NewmarkBeta():

    def __init__(self, beta, gamma, j, c, k, rpm, tvec, torq, taccur, loadtype):
        self.beta = beta
        self.gamma = gamma
        self.tstart = tvec[0]
        self.tend = tvec[1]
        self.acc = taccur
        #self.ntstep = tvec[2]
        self.inert = j
        self.stiff = k
        self.damp = c
        self.rpm = rpm
        self.torq_mean = torq[0]
        self.torq_amp = torq[1]
        self.loadtype = loadtype
        self.ntstep = int(math.ceil((self.tend - self.tstart) * self.get_number_timesteps() * self.acc / 10000) * 10000)

        self.tvec_real = np.array([self.tstart, self.tend, self.ntstep])
        self.torquevec = Load(self.rpm, self.tvec_real).torque_vec

        self.add_load = np.zeros(self.ntstep)
        self.current_timestep = 0

    def initialize_newmark(self):
        # init the matrices
        J = np.diag(self.inert)
        K = np.array([[self.stiff[0], -self.stiff[0]], [-self.stiff[0], self.stiff[0] + self.stiff[1]]])
        C = np.array([[self.damp[0], -self.damp[0]], [-self.damp[0], self.damp[0] + self.damp[1]]])

        return J, C, K

    def initial_step(self, J, C, K, ic):
        # initial time step
        t0 = 0
        id = ic[0, 0:2]
        iv = ic[0, 2:4]

        ddu_n = np.linalg.solve(J, self.load_vec(t0, 1).transpose() - C.dot(iv.transpose()) - K.dot(id.transpose()))

        return ddu_n[0, 0], ddu_n[1, 0]

    def solve_lin(self, idisp, ivel):
        # solver for the linear spring system

        J, C, K = self.initialize_newmark()
        ndof = len(J)
        ddu = np.zeros((ndof, self.ntstep))
        du = np.zeros((ndof, self.ntstep))
        u = np.zeros((ndof, self.ntstep))

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1] - t[0]
        ic = np.bmat('idisp,ivel')
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[0, 0], ddu[1, 0] = self.initial_step(J, C, K, ic)

        for i in range(1, self.ntstep):
            mat_lhs = J + dt * self.gamma * C + dt ** 2 * self.beta * K
            mat_rhs = self.load_vec(t[i], i)[0, :] - C.dot(
                du[:, i - 1] + dt * (1 - self.gamma) * ddu[:, i - 1]) - K.dot(
                u[:, i - 1] + dt * du[:, i - 1] + dt ** 2 / 2 * (1 - 2 * self.beta) * ddu[:, i - 1])

            ddu[:, i] = np.linalg.solve(mat_lhs, mat_rhs)
            du[:, i] = du[:, i - 1] + dt * ((1 - self.gamma) * ddu[:, i - 1] + self.gamma * ddu[:, i])
            u[:, i] = u[:, i - 1] + dt * du[:, i - 1] + dt ** 2 / 2 * (
            (1 - 2 * self.beta) * ddu[:, i - 1] + 2 * self.beta * ddu[:, i])

        return u, du, ddu

    def solve_nl(self, idisp, ivel):
        # solver for the nonlinear (two stage spring system)

        K = self.kmat()
        C = self.cmat()
        J = self.jmat()

        ndof = len(self.stiff)

        error = np.zeros((ndof, self.ntstep))
        ddu = np.zeros((ndof, self.ntstep))
        du = np.zeros((ndof, self.ntstep))
        u = np.zeros((ndof, self.ntstep))

        ic = np.bmat('idisp, ivel')
        u[:, 0] = idisp
        du[:, 0] = ivel

        ddu[0, 0], ddu[1, 0] = self.initial_step(J, C, K, ic)

        t = np.linspace(self.tstart, self.tend, self.ntstep)
        dt = t[1] - t[0]

        for i in range(1, self.ntstep):
            self.current_timestep = i
            u[:, i] = fsolve(self.func3, u[:, i - 1], (u[:, i - 1], du[:, i - 1], ddu[:, i - 1], t[i], dt, J, C, K))

            ddu[:, i] = (1 / (2 * self.beta)) * (
            (u[:, i] - u[:, i - 1] - dt * du[:, i - 1]) * (2 / (dt ** 2)) - (1 - 2 * self.beta) * ddu[:, i - 1])
            du[:, i] = du[:, i - 1] + ((1 - self.gamma) * ddu[:, i - 1] + self.gamma * ddu[:, i]) * dt
            error[:, i] = self.func3(u[:, i], u[:, i - 1], du[:, i - 1], ddu[:, i - 1], t[i], dt, J, C, K)
        return u, du, ddu, error

    def eigenfreq(self):
        # computes the natural eigenvalues
        J, C, K = self.initialize_newmark()
        return eig(K, J)

    def get_number_timesteps(self):
        eigen_v = self.eigenfreq()[0][:]
        omega_max = np.sqrt(np.max(eigen_v.real))
        h_crit = 2 / omega_max
        return 1 / h_crit

    def load_vec(self, t, i):
        # This function returns the loadvector for the linear spring system, for the sine load or the realistic load.
        # The realistic load is called via the library FlywheelTorque_lib3

        omega_f = 2 * np.pi * self.rpm * 3 / 60

        if self.loadtype is 'sine':
            t_eng = self.torq_mean + self.torq_amp * np.sin(omega_f * t)
            t_gear = self.damp[1] * omega_f / 3 + self.stiff[1] * omega_f / 3 * t
        elif self.loadtype is 'real':
            t_eng = self.torquevec[i]
            tt = np.linspace(self.tstart, self.tend, self.ntstep)
            t_gear = self.damp[1] * omega_f / 3 + self.stiff[1] * omega_f / 3 * tt[i]

        return np.array([[t_eng, t_gear]])

    def get_load(self, t, u):
        # This function returns the loadvector for the Two stage spring system

        if u[0] - u[1] > 0.75 * np.pi / 180:
            du_k2 = u[0] - u[1] - 0.75 * np.pi / 180
        elif u[1] - u[0] > 0.75 * np.pi / 180:
            du_k2 = u[0] - u[1] + 0.75 * np.pi / 180
        else:
            du_k2 = 0
        increment = 1

        k2 = increment * self.stiff[0]
        f_nl = np.array([k2 * du_k2, -k2 * du_k2])
        self.add_load[self.current_timestep] = f_nl[0]

        freq = self.rpm * 3 / 60 * 2 * np.pi
        t_gear = self.damp[1] * freq / 3 + self.stiff[1] * freq / 3 * t

        t_eng = self.load_vec(t, self.current_timestep)[0][0]

        return np.array([t_eng, t_gear]) - f_nl

    def kmat(self):
        k11 = self.stiff[0]
        k12 = self.stiff[0]
        k21 = k12
        k22 = self.stiff[0] + self.stiff[1]
        return np.array([[k11, -k12], [-k21, k22]])

    def cmat(self):
        c = self.damp
        c11 = c[0]
        c12 = c[0]
        c21 = c12
        c22 = c[0] + c[1]
        return np.array([[c11, -c12], [-c21, c22]])

    def jmat(self):
        return np.diag(self.inert)

    # Non-linear part in load vector
    def func3(self, u_i, u_old, du_old, ddu_old, t, h, J, C, K):
        p_i = self.get_load(t, u_i)
        ddu_i = 1 / (2 * self.beta) * ((u_i - u_old - h * du_old) * 2 / h ** 2 - (1 - 2 * self.beta) * ddu_old)
        du_i = du_old + ((1 - self.gamma) * ddu_old + self.gamma * ddu_i) * h
        return J.dot(ddu_i) + C.dot(du_i) + K.dot(u_i) - p_i






