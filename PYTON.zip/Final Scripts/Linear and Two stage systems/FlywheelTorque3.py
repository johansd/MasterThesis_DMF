from FlywheelTorque_lib3 import *
import numpy as np
import matplotlib.pyplot as plt

# This script computes and plots the realistic engine torque for two revolutions of the engine crankshaft
# for a chosen engine speed that is in the range of the provided data from Volvo.

# INPUT, choose nrspeeds to 0 or 1, where 0 is one speed and 1 is more speeds
nrspeeds = 1

if nrspeeds == 0:
    speed = 1500
    omega = 2 * np.pi * speed / 60

    tstart = 0
    tend = 4*np.pi/omega    # period time for 2 rev. of the engine crankshaft
    ntstep = 100000
    tvec = np.array([tstart, tend, ntstep])

    torquevec = Load(speed, tvec).torque_vec
    print(torquevec)
    print(np.shape(torquevec))

elif nrspeeds == 1:
    speed = np.array([800, 1400, 2000])

    speed_legend = []
    linetype = ['b', 'g--', 'r:']
    i = 0
    for speed in speed:
        omega = 2*np.pi*speed/60
        tstart = 0
        tend = 4*np.pi/omega
        ntstep = 720
        tvec = np.array([tstart, tend, ntstep])

        torquevec = Load(speed, tvec).torque_vec
        degree = np.linspace(0, 720, ntstep)
        speed_legend.append(str(speed) + ' rpm')

        plt.figure(1)
        plt.plot(degree, torquevec, linetype[i], linewidth=1.5)
        plt.legend(speed_legend)
        plt.xlabel('Crankangle [$^\circ$]')
        plt.ylabel('Torque [Nm]')
        #plt.grid(True)
        plt.grid()
        plt.axis([0, 720, -2000, 10000])
        plt.savefig('figures/TorqueLoad.png', dpi=300)

        i += 1


    plt.show()
