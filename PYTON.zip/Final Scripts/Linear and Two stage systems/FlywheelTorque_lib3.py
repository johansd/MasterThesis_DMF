import numpy as np

class Load():
    def __init__(self, speed, tvec):
        self.speed = speed
        self.omega = 2*np.pi*speed/60
        self.tstart = tvec[0]
        self.tend = tvec[1]
        self.ntstep = tvec[2]
        self.t = np.linspace(self.tstart, self.tend, self.ntstep)

        self.rpm_csvdata = np.array([800, 1000, 1400, 1600, 1800, 2000])    # The engine speeds in the provided data from Volvo

        speedincsv = self.speed in self.rpm_csvdata
        speedinrange = True
        if (self.speed < self.rpm_csvdata[0] or self.speed > self.rpm_csvdata[-1]): speedinrange = False

        if speedincsv == True:
            # computes the realistic engine torque for a engine speed in the provided data and defines it as self.torque_vec
            filename = 'FlywheeltorqueNew/flywheeltorque_at_' + str(self.speed) + 'rpm.csv'
            self.orders = self.read_csv_file(filename)[0]
            self.load_vec = self.read_csv_file(filename)[1]
            self.torque_vec = self.torqueload()

        elif speedincsv == False and speedinrange == True:
            # computes the interpolated engine load (self.torque_vec)
            i = 0
            self.pos = -1
            while self.speed > self.rpm_csvdata[i]:
                self.pos += 1
                i += 1
            self.torque_vectors = []

            for j in range(2):
                filename = 'FlywheeltorqueNew/flywheeltorque_at_' + str(self.rpm_csvdata[self.pos + j]) + 'rpm.csv'
                self.orders = self.read_csv_file(filename)[0]
                self.load_vec = self.read_csv_file(filename)[1]
                torque_vec = self.torqueload()
                self.torque_vectors.append(torque_vec)  # this vector contains the engine torques for the engine speed below the interpolated engine speed and the one above
            self.torque_vec = self.get_interp_torque()  # then the interpolated torque vector is computed using the function: get_interp_torque

        else:
            # error if the chosen engine speed is out of range
            raise out_of_bound("The chosen speed "+str(self.speed)+"is not in the region between the speeds of the given data")

    def read_csv_file(self, filename):
        # reads the CSV file flywheeltorque_at_... for a given engine speed
        f = open(filename)
        lines = f.readlines()
        f.close()
        data = []
        for line in lines:
            data.append(line.split(';'))
        data = np.array(data)

        orders = data[1::, 0]
        load_vec = np.array(data[1::, 1], float) + 1j * np.array(data[1::, 2], float)
        return orders.astype(np.float), load_vec

    def torqueload(self):
        # computes the realistic torque for the provided data from Volvo
        n = 25
        torque = 0
        for i in range(1, n+1):
            torque += (self.load_vec.real[i-1]+1j*self.load_vec.imag[i-1])*np.exp(1j*self.orders[i-1]*self.omega*self.t)
        return torque.real

    def get_interp_torque(self):
        # computes the interpolated torque
        torque_interp = (self.torque_vectors[1]-self.torque_vectors[0])/(self.rpm_csvdata[self.pos+1]-self.rpm_csvdata[self.pos])*(self.speed-self.rpm_csvdata[self.pos])+self.torque_vectors[0]

        return torque_interp

class out_of_bound(Exception):pass