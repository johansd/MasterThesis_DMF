from LinearTwostageSpringSystem_lib import *
import numpy as np
import matplotlib.pyplot as plt

# This script was used to compute the torsional vibration dynamics of the DMF for the linear spring system
# and the two stage spring system. This was solved for the 2 engine torques, the sine load and realistic load and for
# the different structural parameters, A1, A2, B.

# INPUT
system = 'lin'      # 'lin' (linear spring system), 'nonlin' (two stage spring system)
loadtype = 'real'  # 'sine' (simple sine load), 'real' (computed based from data for a Volvo truck engine)
struct_par = 'B'   # 'A1', 'A2', 'B' structural parameters
# A1 - previous Msc. Thesis, A2 - structural parameters A in the Report, B - structural parameters B in the Report

speed = np.array([800, 1400, 2000])
torq = np.array([300, 500])     # [3000, 2000], [300, 500], mean and amplitude for the sine load

if struct_par is 'A1':
    j = np.array([1.8, 0.6])        # moments of inertia [kgm^2]
    k = np.array([20000, 11000])    # torsional stiffness [Nm/rad]
    c = np.array([30, 1])           # torsional viscous damping [Nms/rad]
elif struct_par is 'A2':
    j = np.array([1.8, 0.6])
    k = np.array([20000, 11000])
    c = np.array([300, 10])
elif struct_par is 'B':
    j = np.array([0.9, 1.75])
    k = np.array([12732, 100000])
    c = np.array([300, 10])

plot_time = 0.99

tstart = 0
tend = 10
tvec = np.array([tstart, tend])
taccur = 15

# input parameters for the Newmark-beta method
beta = 0.25
gamma = 0.5

rms_python = np.zeros(len(speed))
speed_legend = []
i = 0
linetype = ['b', 'g--', 'r:']
for rpm in speed:

    print('rpm:')
    print(rpm, '\n')

    omega = 2 * np.pi * rpm / 60

    # Calling the class NewmarkBeta in the library InitialModelEngTorq_lib
    Newmark = NewmarkBeta(beta, gamma, j, c, k, rpm, tvec, torq, taccur, loadtype)

    ntstep = Newmark.ntstep
    t = np.linspace(tstart, tend, ntstep)

    # initial conditions for the disp. and vel.
    idisp = np.array([0, 0])
    ivel = np.array([omega, omega])

    # solves for the angular disp, vel, acc.
    if system is 'lin':
        u, du, ddu = Newmark.solve_lin(idisp, ivel)
    elif system is 'nonlin':
        u, du, ddu, error = Newmark.solve_nl(idisp, ivel)

    Torque_sec = (u[0, :] - u[1, :]) * k[0]     # the torque transferred to the secondary flywheel
    Torque_is = (u[1, :] - omega * t) * k[1]    # the torque transferred to the input shaft of the gearbox

    # computes the RMS values for the curves for the different engine speeds
    rms_python[i] = np.sqrt(1/(0.1)*np.trapz(np.square(u[0, plot_time*ntstep-1:]-u[-1, plot_time*ntstep-1:]), t[plot_time*ntstep-1:]))
    print('RMS-Value')
    print(rms_python[i])

    speed_legend.append(str(rpm) + ' rpm')

    # plot the relative angular displacement (primary-secondary)
    plt.figure(1)
    plt.plot(t[plot_time * ntstep:], u[0, plot_time * ntstep:] - u[1, plot_time * ntstep:], linetype[i], linewidth=1.5)
    plt.legend(speed_legend)    #, loc=5
    plt.xlabel('time [s]')
    plt.ylabel(r'$\theta_{pri}-\theta_{sec}$' ' [rad]')
    plt.grid()
    plt.savefig('figures/figLinDisp.png', dpi=300)

    # plot the transferred torque in to the secondary flywheel
    plt.figure(2)
    plt.plot(t[plot_time * ntstep:], Torque_sec[plot_time * ntstep:], linetype[i], linewidth=1.5)
    plt.legend(speed_legend)    #, loc=5
    plt.xlabel('time [s]')
    plt.ylabel('Torque [Nm]')

    # plot the transferred torque in to the input shaft of the gearbox
    plt.figure(3)
    plt.title('Torque in to the input shaft')
    plt.plot(t[plot_time * ntstep:], Torque_is[plot_time * ntstep:], linetype[i], linewidth=1.5)
    plt.legend(speed_legend)    #, loc=5
    plt.xlabel('time [s]')
    plt.ylabel('Torque [Nm]')

    i += 1

print('Eigenvalues')
print('Eigenmod 1')
print(np.sqrt(Newmark.eigenfreq()[0][0].real)/(2*np.pi*3)*60)
print('Eigenmod 2')
print(np.sqrt(Newmark.eigenfreq()[0][1].real)/(2*np.pi*3)*60)
print('----')
print(np.sqrt(Newmark.eigenfreq()[0][:].real)/(2*np.pi*3)*60)

plt.show()




